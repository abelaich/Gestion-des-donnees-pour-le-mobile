package fr.mastersid.belaich.stforst.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import fr.mastersid.belaich.stforst.data.Etablissement
import fr.mastersid.belaich.stforst.repository.EtablissementRepository
import fr.mastersid.belaich.stforst.repository.EtablissementResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject


@HiltViewModel
class EtablissementViewModel @Inject constructor (
    private val etablissementRepository : EtablissementRepository
) : ViewModel() {
    private val _etablissementList : MutableLiveData<List<Etablissement>> = MutableLiveData ( emptyList () )
    val etablissementList : LiveData<List<Etablissement>> = _etablissementList
    private val _isUpdating = MutableLiveData ( false )
    val errorMessage = MutableLiveData<String?>()

    init {
        viewModelScope.launch ( Dispatchers.IO) {
            etablissementRepository . etablissementResponse . collect { response ->
                when ( response ) {
                    is EtablissementResponse.Pending -> _isUpdating . postValue ( true )
                    is EtablissementResponse.Success -> {
                        _etablissementList.postValue (response.list)
                    }
                    is EtablissementResponse.Error -> _isUpdating . postValue ( false )
                }
            }
        }
    }

    fun updateWeatherList () {
        viewModelScope.launch (Dispatchers.IO) {
            etablissementRepository.updateEtablissementInfo ()
        }
    }
    fun updateQuestions() {
        viewModelScope.launch(Dispatchers.IO) {
            etablissementRepository.updateEtablissementInfo ()

            etablissementRepository.etablissementResponse.collect { response ->
                withContext(Dispatchers.Main) {
                    when (response) {
                        is EtablissementResponse.Error -> errorMessage.value = response.message
                        else -> errorMessage.value = null
                    }
                }
            }
        }
    }
}