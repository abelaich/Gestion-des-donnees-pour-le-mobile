package fr.mastersid.belaich.stforst.adapter

import com.squareup.moshi.FromJson
import com.squareup.moshi.ToJson
import fr.mastersid.belaich.stforst.data.Etablissement
import fr.mastersid.belaich.stforst.data.EtablissementJson
import fr.mastersid.belaich.stforst.data.ListEtablissementJson

class EtablissementMoshiAdapter {
    @FromJson
    fun fromJson(listEtablissementJson: ListEtablissementJson): List<Etablissement> {
        return listEtablissementJson.results.map { etablissementJson ->
            Etablissement(etablissementJson.identifiant_de_l_etablissement, etablissementJson.type_etablissement, etablissementJson.nom_etablissement,
                etablissementJson.nombre_d_eleves.toString()
            )
        }
    }

    @ToJson
    fun toJson(listWeather: List<Etablissement>): ListEtablissementJson {
        return ListEtablissementJson(
            listWeather.map { etablissement ->
                EtablissementJson(etablissement.id, etablissement.type, etablissement.name, etablissement.students.toInt())
            }
        )
    }
}

/*
val id: Int = 0,
val type: String = "",
val name: String = "",
val students: String = "",

*/
