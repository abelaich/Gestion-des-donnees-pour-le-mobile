package fr.mastersid.belaich.stforst.module

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import fr.mastersid.belaich.stforst.repository.EtablissementRepository
import fr.mastersid.belaich.stforst.repository.EtablissementRepositoryDummyImpl
import fr.mastersid.belaich.stforst.repository.EtablissementRepositoryImpl

@Module
@InstallIn( ViewModelComponent :: class )
abstract class EtablissementRepositoryModule {
    @Binds
    abstract fun bindEtablissementRepository ( etablissementRepositoryImpl : EtablissementRepositoryImpl) :
            EtablissementRepository
}