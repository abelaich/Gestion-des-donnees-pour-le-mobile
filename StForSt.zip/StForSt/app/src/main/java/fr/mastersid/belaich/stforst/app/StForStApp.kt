package fr.mastersid.belaich.stforst.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp

class StForStApp : Application()