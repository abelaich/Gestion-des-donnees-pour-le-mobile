package fr.mastersid.belaich.stforst.view

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import fr.mastersid.belaich.stforst.R
import fr.mastersid.belaich.stforst.viewmodel.EtablissementViewModel


@Composable
fun EtablissementScreen (modifier : Modifier, etablissementViewModel: EtablissementViewModel = viewModel()) {


    val EtablissementListNotSorted by etablissementViewModel.etablissementList.observeAsState(emptyList())


    var filterAnswer by remember { mutableStateOf(false) }
    /*val EtablissementListNotSorted = listOf ( // donn ´ee "en dur " : elle sera d´e plac ´ee
        Etablissement (1 , "Saint-Etienne-du-Rouvray ", "Hello me ", "Unknown") , // dans les chapitres suivants !
        Etablissement (2 , " Rouen ", "Rouen ", "Unknown") ,
        Etablissement (3 , " Petit Quevilly ", "Hello me ", "Unknown") ,
    )*/

    val EtablissementList = if (filterAnswer) {
        EtablissementListNotSorted.filter { it.type == "Lycée" }
    } else{
        EtablissementListNotSorted
    }

    val errorMessage by etablissementViewModel.errorMessage.observeAsState(null)
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    Scaffold (
    modifier = modifier ,
        bottomBar = {
            FilterButton(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                text = stringResource(id = R.string.filter_by_etablissement),
                selected = filterAnswer,
                onClick = {filterAnswer = !filterAnswer}

            )},
        floatingActionButton = {
            FloatingActionButton (
                onClick = etablissementViewModel :: updateWeatherList
            ) {
                Icon (
                    Icons . Default . Refresh ,
                    stringResource (id = R.string.refresh_button_content_description)
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }


    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(EtablissementList) { etablissement ->
                    EtablissementRow(etablissement)
                }
                item {
                    Spacer ( modifier = Modifier . height (64. dp) )
                }
            }

        }
    }




}