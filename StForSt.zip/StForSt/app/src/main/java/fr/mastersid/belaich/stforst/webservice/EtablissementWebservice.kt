package fr.mastersid.belaich.stforst.webservice

import fr.mastersid.belaich.stforst.data.Etablissement
import retrofit2.http.GET
import retrofit2.http.Query



//records?where=code_postal%3D%2276800%22
interface EtablissementWebservice {
    @GET("records?where=code_postal%3D%2276800%22")
    suspend fun getEtablissementList (
        //@Query("where") where : String = "code_postal%3D%2276800%22",
        @Query("limit") limit : Int = 50,
    ) : List<Etablissement>
}
