package fr.mastersid.belaich.stforst.repository

import kotlinx.coroutines.flow.Flow

interface EtablissementRepository {
    val etablissementResponse : Flow<EtablissementResponse>
    suspend fun updateEtablissementInfo ()
}