package fr.mastersid.belaich.stforst.repository

import fr.mastersid.belaich.stforst.data.Etablissement

sealed interface EtablissementResponse {
    object Pending : EtablissementResponse
    @JvmInline
    value class Success (val list : List <Etablissement>) : EtablissementResponse
    data class Error(val message: String) : EtablissementResponse
}