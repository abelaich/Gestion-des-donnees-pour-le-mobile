package fr.mastersid.belaich.stforst.module

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import fr.mastersid.belaich.stforst.adapter.EtablissementMoshiAdapter
import fr.mastersid.belaich.stforst.webservice.EtablissementWebservice
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

private const val BASE_URL = "https://data.education.gouv.fr/api/explore/v2.1/catalog/datasets/fr-en-annuaire-education/"
@Module
@InstallIn( SingletonComponent :: class )
object EtablissementWebserviceModule {
    @Provides
    fun provideMoshi () : Moshi {
        return Moshi . Builder ()
            .add( KotlinJsonAdapterFactory () )
            .add( EtablissementMoshiAdapter () )
            . build ()
    }

    @Provides
    fun provideRetrofit ( moshi : Moshi) : Retrofit {
        return Retrofit . Builder ()
            . addConverterFactory ( MoshiConverterFactory . create ( moshi ) )
            . baseUrl ( BASE_URL )
            . build ()
    }


    @Provides
    fun provideWeatherWebservice(retrofit: Retrofit): EtablissementWebservice {
        return retrofit.create(EtablissementWebservice::class.java)
    }
}