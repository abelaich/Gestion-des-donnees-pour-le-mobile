package fr.mastersid.belaich.stforst.preview

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import fr.mastersid.belaich.stforst.data.Etablissement
import fr.mastersid.belaich.stforst.ui.theme.StForStTheme
import fr.mastersid.belaich.stforst.view.EtablissementRow

@Preview( showBackground = true , widthDp = 400)
@Composable
fun WeatherRowPreview () {
    StForStTheme {
        EtablissementRow ( Etablissement ("1" , "Université de Rouen Normandie", "Madrillet", "1"))
    }
}
