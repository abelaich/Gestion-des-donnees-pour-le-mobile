package fr.mastersid.belaich.stforst.data


data class Etablissement(
    val id: String = "",
    val type: String = "",
    val name: String = "",
    val students: String = "unknown",
)
