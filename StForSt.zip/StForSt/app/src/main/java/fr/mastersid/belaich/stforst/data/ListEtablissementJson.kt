package fr.mastersid.belaich.stforst.data

data class ListEtablissementJson (
    val results : List < EtablissementJson >
)
data class EtablissementJson(
    val identifiant_de_l_etablissement: String,
    val type_etablissement: String,
    val nom_etablissement: String,
    val nombre_d_eleves: Int?,
)
