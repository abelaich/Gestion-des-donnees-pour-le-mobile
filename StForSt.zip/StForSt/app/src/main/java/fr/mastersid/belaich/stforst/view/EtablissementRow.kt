package fr.mastersid.belaich.stforst.view

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import fr.mastersid.belaich.stforst.R
import fr.mastersid.belaich.stforst.data.Etablissement
import java.lang.reflect.Modifier


@Composable
fun EtablissementRow ( etablissement : Etablissement) {
    Row( horizontalArrangement = Arrangement.spacedBy(16.dp) ) { // espace entre les éléments
        Text (
            text = etablissement.name ,
            maxLines = 1 ,
            overflow = TextOverflow.Ellipsis, // pointillés finaux si le texte est trop long
            modifier = androidx.compose.ui.Modifier.weight(1f) // prend le maximum de place
        )
        when(etablissement.students == "null"){
            true -> Text ( text = stringResource (id = R.string.studentCountUnknown))
            false -> Text ( text = stringResource (id = R.string.studentCount, etablissement.students))
        }
    }
}