package fr.mastersid.belaich.stforst.repository

import fr.mastersid.belaich.stforst.data.Etablissement
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject

class EtablissementRepositoryDummyImpl @Inject constructor () : EtablissementRepository {
    override val etablissementResponse : MutableStateFlow<EtablissementResponse> = MutableStateFlow (
        EtablissementResponse . Success ( emptyList () )
    )
    override suspend fun updateEtablissementInfo () {
        etablissementResponse.emit(EtablissementResponse.Pending)
        delay (1000)
        etablissementResponse . emit (
            EtablissementResponse . Success (
                listOf (
                    Etablissement ("1" , "Saint-Etienne-du-Rouvray ", "Hello me ", "Unknown") ,
                    Etablissement ("1" , "Saint-Etienne-du-Rouvray ", "Hello me ", "Unknown") ,
                    Etablissement ("1" , "Saint-Etienne-du-Rouvray ", "Hello me ", "Unknown") ,
                )
            )
        )
    }
}