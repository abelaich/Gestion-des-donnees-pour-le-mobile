package fr.mastersid.belaich.stforst.repository

import android.util.Log
import fr.mastersid.belaich.stforst.webservice.EtablissementWebservice
import kotlinx.coroutines.flow.MutableStateFlow
import retrofit2.HttpException
import java.io.IOException
import java.text.Normalizer
import javax.inject.Inject

class EtablissementRepositoryImpl @Inject constructor (
    private val etablissementWebservice : EtablissementWebservice
) : EtablissementRepository {
    override val etablissementResponse : MutableStateFlow<EtablissementResponse> = MutableStateFlow (
        EtablissementResponse . Success ( emptyList () )
    )
    override suspend fun updateEtablissementInfo () {
        etablissementResponse . emit (EtablissementResponse . Pending )
        try {
            val list = etablissementWebservice.getEtablissementList()

            val uniqueList = list.distinctBy { etablissement ->
                "\\p{InCombiningDiacriticalMarks}".toRegex()
                    .replace(Normalizer.normalize(etablissement.id, Normalizer.Form.NFD), "")
            }
            etablissementResponse.emit(EtablissementResponse.Success(uniqueList)) // Succès

        } catch (e: IOException) {
            Log.e("QuestionRepository", "Erreur réseau", e)
            etablissementResponse.emit(EtablissementResponse.Error("Network error")) // Erreur réseau
        } catch (e: HttpException) {
            Log.e("QuestionRepository", "Erreur requête HTTP", e)
            etablissementResponse.emit(EtablissementResponse.Error("Request error")) // Erreur HTTP
        } catch (e: Exception) {
            Log.e("QuestionRepository", "Erreur inconnue", e)
            etablissementResponse.emit(EtablissementResponse.Error(e.message ?: "Erreur inconnue")) // Autres erreurs
        }
    }
}